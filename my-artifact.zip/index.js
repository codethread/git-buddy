// @bun
var o=`Hello Bun! ${"0.0.1"}`;console.log(o);export{o as message};
